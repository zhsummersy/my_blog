#PhotoBay

This is a partially complete Photo Blog.
It has a Home, Blog, Contact section.
Users need to login to create a post. Forgot Password option is also present.
It was made with Django and Frontend was done with Bootstrap.




