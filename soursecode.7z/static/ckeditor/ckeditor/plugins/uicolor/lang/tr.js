﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","tr",{title:"UI Renk Seçici",preview:"Canlı ön izleme",config:"Bu yazıyı config.js dosyasının içine yapıştırın",predefined:"Önceden tanımlı renk seti"});